<?php

?>
<h1>Over ons</h1>
<h2>Wie zijn wij</h2>
<p>
    <img height="175" src="media/mensen.jpg" alt="wij" class="imgRight" />

    Wij zijn Thomas Kool & Max Groenendijk.
    Samen zijn wij de drankwinkel 'Het Drankorgel' begonnen.
    Zelf zijn wij echte gezelligheid drinkers en daarom zijn wij op het idee gekomen
    om onze ervaring met verschillende soorten dranken te delen met iedereen.
    Op onze website staan verschillende soorten dranken.</p>
<br /><br /><br />
<h2>Routebeschrijving</h2>
<p>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4914.020354053896!2d5.950218097538879!3d51.98846814138435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0000000000000000%3A0x076f2727a90f3906!2sHogeschool+van+Arnhem+en+Nijmegen!5e0!3m2!1snl!2snl!4v1423561927838" width="400" height="300" class="imgRight"></iframe>
    Fusce porta nisl ut dictum tincidunt. Proin suscipit orci fringilla ex suscipit,
    nec venenatis ante accumsan. Maecenas egestas consectetur ex vel sollicitudin.
    Mauris nec orci volutpat, finibus justo in, gravida nisl.
    Aliquam in felis non ante fermentum finibus eu ac sem.


    Etiam sodales, nibh porttitor iaculis efficitur, enim lectus porttitor mauris,
    vitae finibus ligula risus eget lectus. Pellentesque sit amet ipsum lacus.
    Curabitur eget ipsum at lacus luctus ullamcorper vel sit amet nisl.
    Vivamus fermentum gravida odio sed elementum. Curabitur id massa vel mauris euismod lobortis.
    Pellentesque metus diam, imperdiet at porttitor vel, ultricies vitae quam.
    Integer eget consequat massa. Praesent dolor odio, pretium vestibulum massa ut,
    luctus luctus erat.
</p>
<br /><br />