<?php

?>

<h1>Vacatures</h1>
<p>Op dit moment hebben wij 2 vacatures.</p>
<h3>
    Sales-medewerker
</h3>
<h4>
    Functieomschrijving
</h4>
<p>
    Drankwinkel Het Drankorgel zoekt een enthousiaste collega die verstand heeft
    van marketing. We zoeken iemand die ons kan helpen met het bedenken van nieuwe
    acties en aanbiedingen. Bij het bedenken van een campagne om meer naamsbekendheid
    te krijgen onder het winkelend publiek.
</p>
<h4>
    Iets voor jou?
</h4>
<p>
    Solliciteer dan direct door ons te mailen
    <a href="mailto:sollicitatie@hetdrankorgel.nl">sollicitatie@hetdrankorgel.nl</a>.
    Doe dit voor 1 juni 2015! Ook voor meer informatie over de functie kunt u
    altijd mailen.
</p>
<br />
<h3>
    Web developer
</h3>
<h4>
    Functieomschrijving
</h4>
<p>
    Drankwinkel Het Drankorgel zoekt een enthousiaste collega die kan helpen
    met het onderhouden en verder ontwikkelen van de onze website en webshop.
    Voor deze functie zoeken wij iemand die werkervaring heeft in een soortgelijke
    functie.
</p>
<h4>
    Iets voor jou?
</h4>
<p>
    Solliciteer dan direct door ons te mailen
    <a href="mailto:sollicitatie@hetdrankorgel.nl">sollicitatie@hetdrankorgel.nl</a>.
    Doe dit voor 1 april 2015! Ook voor meer informatie over de functie kunt u
    altijd mailen.
</p>
<br /><br />
