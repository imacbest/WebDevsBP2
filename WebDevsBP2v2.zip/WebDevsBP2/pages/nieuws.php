
<h1>Nieuws</h1>
<h2>Nieuw in het assortiment</h2>
<p>
    <img height="125" src="media/producten/Grolsch_Beugel_XXL_150.png" alt="wij" class="imgLeft" />
</p>
<h3>Grolsch Pils Beugel XXL</h3>
<p>
    Grolsch Pils in een groene XXL Beugel verpakt.
    Mooi om weg te geven maar nog beter om te krijgen.
    De fles heeft een inhoud van 1,5 liter. Alcoholpercentage 5 %.
    Daarom zijn wij blij dat wij dit perfecte cadeau aan ons assortiment
    hebben kunnen toevoegen.
    <br /><br />
    <a href="?product&amp;pid=12">Ga naar Grolsch Pils Beugel XXL in de Webshop</a></p>
<br />
<p>
    <img height="125" src="media/producten/Puschkin_Red_100.png" alt="wij" class="imgLeft" />
</p>
<h3>Puschkin Red</h3>
<p>
    Puschkin Red Orange (17,7%) combineert de kracht van Puschkin wodka met de
    heerlijke bitterzoete smaak van rode bloedsinaasappelen. Deze kenmerkende smaak
    maakt Red Orange ongekend populair, Puschkin Red Orange is niet voor niets al jarenlang
    Nederland’s nummer 1 rode wodka. Puschkin Red Orange is heerlijk in de mix.
    <br /><br />
    <a href="?product&amp;pid=35">Ga naar Puschkin Red in de Webshop</a>
</p>
<br /><br /><br />
<h2>Denk alvast aan de zomer</h2>
<p>
    Fusce porta nisl ut dictum tincidunt. Proin suscipit orci fringilla ex suscipit,
    nec venenatis ante accumsan. Maecenas egestas consectetur ex vel sollicitudin.
    Mauris nec orci volutpat, finibus justo in, gravida nisl.
    Aliquam in felis non ante fermentum finibus eu ac sem.


    Etiam sodales, nibh porttitor iaculis efficitur, enim lectus porttitor mauris,
    vitae finibus ligula risus eget lectus. Pellentesque sit amet ipsum lacus.
    Curabitur eget ipsum at lacus luctus ullamcorper vel sit amet nisl.
    Vivamus fermentum gravida odio sed elementum. Curabitur id massa vel mauris euismod lobortis.
    Pellentesque metus diam, imperdiet at porttitor vel, ultricies vitae quam.
    Integer eget consequat massa. Praesent dolor odio, pretium vestibulum massa ut,
    luctus luctus erat.
</p>
<br /><br />
<h2>Stage lopen bij ons?</h2>
<p>
    Fusce porta nisl ut dictum tincidunt. Proin suscipit orci fringilla ex suscipit,
    nec venenatis ante accumsan. Maecenas egestas consectetur ex vel sollicitudin.
    Mauris nec orci volutpat, finibus justo in, gravida nisl.
    Aliquam in felis non ante fermentum finibus eu ac sem.


    Etiam sodales, nibh porttitor iaculis efficitur, enim lectus porttitor mauris,
    vitae finibus ligula risus eget lectus. Pellentesque sit amet ipsum lacus.
    Curabitur eget ipsum at lacus luctus ullamcorper vel sit amet nisl.
    Vivamus fermentum gravida odio sed elementum. Curabitur id massa vel mauris euismod lobortis.
    Pellentesque metus diam, imperdiet at porttitor vel, ultricies vitae quam.
    Integer eget consequat massa. Praesent dolor odio, pretium vestibulum massa ut,
    luctus luctus erat.
    <br /><br />
    Interresse? Mail naar <a href="mailto:stage@hetdrankorgel.nl">stage@hetdrankorgel.nl</a>!
</p>
<br /><br />